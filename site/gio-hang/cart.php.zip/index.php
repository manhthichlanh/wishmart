<?php
    require_once "../../global.php";
    require "../../dao/san-pham.php";
    extract($_REQUEST);
    // var_dump($_REQUEST);
    if (exist_param("add_to_cart")) {
        
        $fg = 0;
        if (isset($_SESSION['client_user'])) {
          
            $id_kh=$_SESSION['client_user']['id_kh'];
            

           
            $list = gio_hang_select_by_id_kh($id_kh);
 
            if (count($list)>0) {

                foreach ($list as $sp) {
                    if($sp['id_sp']==$id_sp) {
                        gio_hang_update_sl($so_luong,$id_kh);
                        $fg=1;
                        break;
                    }

                }
            } 
            if ($fg==0) {

                gio_hang_insert_by_id_kh($id_sp,$so_luong,$hinh,$don_gia,$ten_sp,$id_kh);        
                
            }

            $client_cart = gio_hang_select_by_id_kh($id_kh);
       
          }
          else {
            

            if (!isset($_SESSION['cart'])) $_SESSION['cart']=array();
              
            
            
            if (count($_SESSION['cart'])>0) {
                $i=0;
                foreach ($_SESSION['cart'] as $sp) {
                    if($sp[0]==$id_sp) {
                        $so_luong+=$sp[1];
                        $_SESSION['cart'][$i][1]=$so_luong;
                        $fg=1;
                        break;
                    }
                    $i++;
                }
            } 

            if ($fg==0) {
                $items=array($id_sp,$so_luong,$hinh,$don_gia,$ten_sp,$so_luong_max);
                if (!isset($_SESSION['cart'])) $_SESSION['cart']=array();
                array_push($_SESSION['cart'],$items);
            }

            if (exist_param("del_cart")) {
                if (isset($id)) {
                    array_splice($_SESSION['cart'],$id,1);
                    // array_splice($_SESSION['cart'],$_GET['id'],1);          
                } else {
                    unset($_SESSION['cart']);
                    $_SESSION['cart']=array();
                } 
                
        }
    

        header("location: $SITE_URL/gio-hang");
    }
        

    }
   
    
    



        $VIEW_NAME = "gio-hang/cart.php";
        require_once "../layout.php";
        echo '<link rel="stylesheet" href="'.$CONTENT_URL.'/css/shopping_cart.css">';
 
   
?>