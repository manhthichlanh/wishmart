<?php
    require_once "../../global.php";
    
    $VIEW_NAME = "dang-nhap/dang-nhap-form.php";

    require_once "../layout.php";
?>