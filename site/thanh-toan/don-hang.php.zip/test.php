<?php
    session_start();
    if (isset($_SESSION['ma_dh'])) echo $_SESSION['ma_dh'];
?>