<?php
    require_once "../../global.php";
    require_once "../../dao/san-pham.php";
    require_once "../../dao/don-hang.php";
    
    // require_once "../data.php";
    extract($_REQUEST);  

    if (isset($_SESSION['client_user'])) {
        $id_kh=$_SESSION['client_user']['id_kh']; 
    } 

    $id_dh= rand(10,999999);
    
    $hoan_thanh=false;

    if (isset($thanh_toan_don_hang)) {

        don_hang_insert($id_dh, $ten_nguoi_nhan, $dia_chi,$email,$sdt,$ghi_chu,$pttt,"Đang duyệt",$id_kh);
        
        $items=ma_dhct($id_kh);
            foreach ($items as $item) {
                extract($item);
                thanh_toan($id_dh,$id_kh,$id_dhct);
            }
            $hoan_thanh=true;

            $_SESSION['ma_dh']=$id_dh;

    }
   
    if ($hoan_thanh==true) {
        $VIEW_NAME = "thanh-toan/hoan-thanh.php";
        $list = don_hang_hoan_thanh($_SESSION['ma_dh']);
        $hoan_thanh=!$hoan_thanh;


        
    } else {
        $VIEW_NAME = "thanh-toan/don-hang.php";
    }
    // var_dump($VIEW_NAME);
    if (isset($id_kh)) $items = gio_hang_select_by_id_kh($id_kh);
    
    require_once "../layout.php";
    echo '<link rel="stylesheet" href="'.$CONTENT_URL.'/css/shopping_cart.css">';

?>